<?php

session_start();

//Hvis user_id allerede "isset" betyder det, at man allerede er logget ind. Dermed bliver man smidt tilbage til startsiden.
if( isset($_SESSION['user_id'])){
    header("location: index.php");
}
//database.php indeholder alle informationer fra databasen
require 'database.php';


if(!empty($_POST['email']) && !empty($_POST['password'])):

    $records = $conn->prepare('SELECT id,email,password FROM users WHERE email = :email');
    $records->bindParam(':email', $_POST['email']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $message = '';

//Hvis user_id og password matcher med dem, der ligger i databasen, bliver man logget ind og dirigeret til startsiden. Hvis ikke, vises meddelelsen "Sorry, wrong email or password".
    if(count($results) > 0 && password_verify($_POST['password'], $results['password'])){
        $_SESSION['user_id'] = $results['id'];
        header("Location: index.php");
    } else {
        $message = 'Sorry, wrong email or password';
    };
    
endif;
?>



<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>

<body>

<div class="header">
    <a href="index.php">Back</a>
</div>


<?php if(!empty($message)): ?>
    <p><?= $message ?></p>
    <?php endif; ?>
    
    <h1>Login</h1>
        <form action="login.php" method="post">
        <input type="text" placeholder="Username" name="email">
        <input type="password" placeholder="Password" name="password">
        <input type="submit" value="Log in">

    <span><br>Not a member yet? <a href="register.php">Register here</a></span>        
            
</body>
</html>
