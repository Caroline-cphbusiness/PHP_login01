<?php

$server = 'localhost';
$username = 'carorasmussen_d';
$password = 'oBYgCKkm';
$database = 'carorasmussen_d';

try {
    $conn = new PDO("mysql:host=$server;dbname=$database;", $username, $password);
} catch(PDOException $e) {
    die( "connection failed:" . $e->getMessage());
}

?>