<?php

session_start();

if( isset($_SESSION['user_id'])){
    header("location: index.php");
}

require 'database.php';

$message = '';

if(!empty($_POST['email']) && !empty($_POST['password'])):

// Enter the new user in the database

    $sql = "INSERT INTO users (email, password) VALUES (:email, :password)";
        $stmt = $conn->prepare($sql);

    $stmt->bindParam(':email', $_POST['email']);
    $stmt->bindParam(':password', password_hash($_POST['password'], PASSWORD_BCRYPT));

    if($stmt->execute() ):
        //die('Succes');
        $message = 'Successfully created new user';
    else:
        //die('Fail');
        $message = 'Sorry, there must have been an issue creating your account';
    endif;

endif;

?>


<!DOCTYPE html>
<html lang="">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>

<body>
    
<div class="header">
    <a href="index.php">Back</a>
</div>
    
<?php
    if(!empty($message)): ?>
    <p><?= $message ?></p>
    <?php endif; ?>
    
    <h1>Register</h1>
    
    <form action="register.php" method="post">
        <input type="text" placeholder="Username" name="email">
        <input type="password" placeholder="Password" name="password">
        <input type="password" placeholder="Confirm password" name="password">
        <input type="submit" value="Register">
    
<span><br>Already a member? <a href="login.php">Log in here</a></span>

    
    
</body>
</html>
